# Merge report: PMS Paper 6 content merged into Islamic Studies Academy

Rule used: a topic is added only once. If an existing chapter already covers the subject, the PMS topic is NOT added again.

## New chapters (category "PMS Paper 6 - Additional Topics", chapters 19-26)
- ch19 Foundations and Impact of Islam: Introduction to Islam: advent, importance and basic beliefs (Aqaid), Religious, spiritual, moral and social impact of Islam, Individual and society, Amar bil Maroof wa Nahi anil Munkar
- ch20 Seerat-un-Nabi: Life and Distinctions: Prophet Muhammad (PBUH) as Messenger and reformer, Distinctive characteristics (Khasais)
- ch21 Early Islamic History: Prophetic period, Era of Hazrat Abu Bakr (RA), Era of Hazrat Umar (RA), Era of Hazrat Usman (RA), Era of Hazrat Ali (RA)
- ch22 Minorities and Objectives of Shariah: Rights of minorities, Maqasid-ul-Shariah
- ch23 Islam and the World: Islam’s impact on the West, Western influence on the Muslim world, Role of Islam in the modern world, Contemporary challenges for the Muslim world, Muslim minorities
- ch24 Islamic Code of Life: Islamic sociopolitical system, Islamic economic system, Concept of Riba (interest)
- ch25 Sources of Islamic Law and Fiqh: Sources and foundations of Islamic law, Understanding Islamic jurisprudence
- ch26 Ethics (for non-Muslim candidates): Meaning and scope of ethics, Development of human moral conduct, Moral theories, Moral ethics and society, Ethical values and human behaviour, Moral responsibilities, Ethical decision-making, Moral teachings of major religions

## PMS topics NOT added (already covered by an existing chapter)
- A2 Fundamentals of Islam (Arkan-e-Islam)  ->  already in ch07 Kalimah Shahadah, ch08 Salah, ch09 Sawm, ch10 Zakah, ch11 Hajj
- B2 Prophet Muhammad (PBUH) as administrator and educator  ->  already in ch17 Administrator; Educator & Reformer (educational reforms)
- B3 Prophet Muhammad (PBUH) as diplomat and statesman  ->  already in ch17 Diplomat; Peace Maker
- B4 Prophet Muhammad (PBUH) as military leader  ->  already in ch17 Military Leader; ch12 Jihad; ch15 Rights of Enemies in War
- D1 Status and rights of women  ->  already in ch14 The Status of Women in Islam
- D4 Human rights in Islamic teachings  ->  already in ch16 Islam and Fundamental Human Rights
- F4 Islamic judicial system  ->  already in ch06 Judicial System; Principles of Justice
- F5 Islamic administrative system  ->  already in ch06 The Rightly Guided Caliphs' System of Government

Their 12 MCQs each were kept and attached to the matching existing chapter.

## PMS headings left out inside kept topics (already covered)
- A1 / Meaning of Islam and Iman  ->  already in ch01 Islam: Meaning and Concept
- A1 / Arabia before Islam (Jahiliyyah)  ->  already in ch17 The Condition of the Arabs Before Islam
- A1 / Tawhid (oneness of Allah)  ->  already in ch03 Tawhid
- A1 / Risalat (prophethood)  ->  already in ch04 Risalah
- A1 / Akhirah (belief in the Hereafter)  ->  already in ch05 Akhirah
- B1 / The Last Sermon and completion of the mission  ->  already in ch18 The Farewell Sermon
- B5 / Khatam-un-Nabiyyin: the Seal of the Prophets  ->  already in ch04 Finality of Prophethood
- B5 / Universal mission: mercy for all worlds  ->  already in ch04 Universality
- B5 / The Quran: the everlasting miracle  ->  already in ch04 A Preserved Book
- C1 / Farewell Hajj and the Last Sermon (10 AH)  ->  already in ch18 The Farewell Sermon
- E4 / Economic backwardness and dependency  ->  already in ch13 Economic Instability / Industrial Backwardness
- E4 / Educational and scientific backwardness  ->  already in ch13 Scientific Decline
- E4 / Disunity of the Ummah  ->  already in ch13 Unity and Solidarity / Disputes Among Muslim Countries
- E4 / Women, youth and human rights implementation  ->  already in ch14 The Status of Women in Islam
- E4 / Way forward: strategies for revival  ->  already in ch13 Remedies
- F1 / Foundations of the Islamic sociopolitical system  ->  already in ch06 Supreme Sovereignty
- F1 / Concept of the Islamic state  ->  already in ch06 The Concept of Khilafah
- F1 / Shura (consultation)  ->  already in ch06 Shura (Consultation)
- F1 / Justice and the rule of law  ->  already in ch06 Principles of Justice
- F1 / Head of state: selection, qualities and accountability  ->  already in ch06 The Caliph
- F1 / Rights and duties of citizens  ->  already in ch16 Rights of Citizens in an Islamic State
- F1 / Role of the community: Amar bil Maroof wa Nahi anil Munkar  ->  already in ch19 Amar bil Maroof (kept in PMS chapter)

## Numbers
- New lessons added: 299
- Questions added: 468 (96 attached to existing chapters)
- Glossary words added: 416
