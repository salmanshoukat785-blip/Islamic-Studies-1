# Islamic Studies Academy (Android)

Kotlin + Jetpack Compose, offline-first, Urdu + English (only the optional "Translate to Urdu" button uses the internet).

## Status
- All app features are built (parts A1 to A6). The PIN lock was removed. See RELEASE.md for building and signing.
- Course content: chapters 1 and 2 are written in Urdu and English; chapters 3 to 16 and 18 are written in Urdu and English. Chapter 17 is written in English only (lessons can be read in Urdu through the online "Translate to Urdu" button).
  Chapter 17 has 11 English-only questions. The home screen follows the new dashboard design. Every heading has an English title. All content is draft until a scholar reviews it. See CONTENT_GUIDE.md.
- The outline of all 18 chapters (55 sub-headings, 453 topics) comes from the original DOCX.

## Merged content (version 0.10.0)
- Chapters 19 to 26 were added from the PMS Paper 6 course (Islamic Studies / Ethics), English only. On the Chapters tab they appear under the header "PMS Paper 6 - Additional Topics"; chapters 1 to 18 stay under "Core Islamic Studies Course".
- No topic is duplicated: PMS topics already covered by chapters 1 to 18 were not added again (see MERGE_REPORT.md). Their MCQs were kept and attached to the existing chapter.
- Each PMS heading is a lesson: Short = short answer plus sub-heading points; Long = full detail, sub-headings and relevant headings. 416 vocabulary words were added to the glossary (underlined, with Urdu meaning).
- Files: assets/content/ch19..ch26_pms_en.json, assets/questions/pms_questions.json, glossary.json, master_outline.json.

## Display changes (version 0.10.1)
- Titles (chapters, headings, lesson page, home cards) now show only the selected app language, not both.
- The pink "Draft: not yet reviewed by a scholar" banner on lessons and the draft notice on the quiz home screen were removed.

## Part A6 (this version)
- Unit tests (streak, PIN hashing, helpers, content integrity) run by the Build APK workflow
- One stable signing key for all builds; optional own release key via GitHub Secrets (see RELEASE.md)
- Release workflow producing a signed APK and an AAB; CONTENT_GUIDE.md for lesson/question files

## Part A5
- Progress screen (overall, per chapter, study streak, quiz stats)
- Settings (profile, languages, level, text size, theme, PIN, reminder, backup/restore, reset)
- Daily study reminder (local notification), backup/restore to a JSON file of your choice

## Part A4
- Search across topic titles and lesson text
- Quiz: Practice (instant feedback), Timed (30 s per question), Mock test (all chapters, one timer), Review mistakes
- Results with full review of every question, attempt history
- Questions are imported from `app/src/main/assets/questions/*.json` (127 draft questions in total; the scholar must review them)

## Part A3
- Lesson reader: Short / Long switch (Short = basic text, Long = basic + intermediate + advanced), tabs Notes / Key Points / MCQs / Vocabulary / My Notes, Urdu / English / both, text size, light/dark/system theme
- Bookmarks, personal notes, mark as completed, previous/next lesson, continue where you left off
- Lesson content is imported from `app/src/main/assets/content/*.json` (one SAMPLE draft lesson included: chapter 1 > اسلام معنی و مفہوم)

## Part A2
- Splash screen, onboarding (language, 3 intro pages, name + level, optional 4-digit PIN)
- PIN lock screen (salted + hashed, stored only on the phone)
- Topic list of a chapter: "Studied X / N" progress, search box, section headers and topic cards
- Home dashboard: tabs Chapters / Saved / Course Outline / Study / Guide, "Studied X / N" by chapters, search box and chapter cards
- Glossary (assets/glossary.json, 60 draft terms): underlined words in lessons open their meaning, and the Vocabulary tab lists them
- No onboarding: the app opens straight to the dashboard (default level Basic) and Urdu/English UI switch (Urdu = right-to-left layout)
- Settings stored with DataStore

## Part A1
- Project setup (Gradle, Compose, Material 3, Navigation, Room)
- Theme (navy / emerald / gold / warm white, light + dark)
- Room database (chapters, headings, lesson sections, questions, quiz attempts, progress, bookmarks, notes)
- Import of `app/src/main/assets/master_outline.json` (chapter > sub-heading > topic) into the database
- Temporary screens: chapter list and chapter detail (to check the outline on a real phone)

## Build
- GitHub: upload `app.zip` to the repo root (see `build-apk.yml`); the APK appears under Actions > Artifacts.
- Android Studio: open this folder, let it sync, run `app`.
