package com.islamicstudies.academy.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.islamicstudies.academy.BuildConfig

@Database(
    entities = [
        ChapterEntity::class,
        HeadingEntity::class,
        LessonSectionEntity::class,
        QuestionEntity::class,
        QuizAttemptEntity::class,
        UserProgressEntity::class,
        BookmarkEntity::class,
        PersonalNoteEntity::class,
        MetaEntity::class,
        TranslationEntity::class
    ],
    version = 2,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun contentDao(): ContentDao
    abstract fun userDao(): UserDao
    abstract fun quizDao(): QuizDao
    abstract fun translationDao(): TranslationDao

    companion object {
        /** Version 1 -> 2: adds the translation cache. No existing table is touched. */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `translations` (" +
                        "`srcHash` TEXT NOT NULL, `textUr` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, " +
                        "PRIMARY KEY(`srcHash`))"
                )
            }
        }

        fun build(context: Context): AppDatabase {
            val builder = Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "islamic_academy.db"
            )
            builder.addMigrations(MIGRATION_1_2)
            // Development builds only: if the schema changes between test APKs, rebuild the DB.
            // Release builds will get proper migrations before the final release.
            if (BuildConfig.DEBUG) {
                builder.fallbackToDestructiveMigration()
            }
            return builder.build()
        }
    }
}
