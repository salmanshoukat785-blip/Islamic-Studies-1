package com.islamicstudies.academy.data.translate

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest

/** Turns text from one language into another. Swap the implementation in ONE place (see Translators). */
interface Translator {
    /** Throws IOException when the network or the service fails. */
    suspend fun translate(text: String, from: String, to: String): String
}

object Translators {
    val default: Translator = WebTranslator()
}

/**
 * Online translation through Google's public web endpoint (no API key).
 * NOTE: this endpoint is unofficial and may change or limit use. Before a Google Play release,
 * switch to the official Cloud Translation API (needs a key) by replacing this one class.
 */
class WebTranslator : Translator {

    override suspend fun translate(text: String, from: String, to: String): String =
        withContext(Dispatchers.IO) {
            val out = StringBuilder()
            for (chunk in splitForTranslation(text, MAX_CHUNK)) {
                if (out.isNotEmpty()) out.append(' ')
                out.append(translateChunk(chunk, from, to))
            }
            out.toString().trim()
        }

    private fun translateChunk(chunk: String, from: String, to: String): String {
        val q = URLEncoder.encode(chunk, "UTF-8")
        val url = URL(
            "https://translate.googleapis.com/translate_a/single?client=gtx" +
                "&sl=$from&tl=$to&dt=t&q=$q"
        )
        val conn = url.openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 10_000
            conn.readTimeout = 20_000
            conn.requestMethod = "GET"
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Android)")
            val code = conn.responseCode
            if (code != 200) throw IOException("Translation service returned HTTP $code")
            val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { r -> r.readText() }
            val result = parseWebResponse(body)
            if (result.isBlank()) throw IOException("Empty translation")
            return result
        } finally {
            conn.disconnect()
        }
    }

    companion object {
        const val MAX_CHUNK = 900
    }
}

/** The response looks like [[["urdu part","english part",...],["urdu part 2",...]],...]. */
fun parseWebResponse(json: String): String {
    val root = JSONArray(json)
    val parts = root.optJSONArray(0) ?: return ""
    val sb = StringBuilder()
    for (i in 0 until parts.length()) {
        val piece = parts.optJSONArray(i) ?: continue
        sb.append(piece.optString(0, ""))
    }
    return sb.toString()
}

/** Splits long text at sentence ends (then at spaces) so every piece is at most maxLen characters. */
fun splitForTranslation(text: String, maxLen: Int): List<String> {
    val clean = text.trim()
    if (clean.isEmpty()) return emptyList()
    if (clean.length <= maxLen) return listOf(clean)
    val out = ArrayList<String>()
    var rest = clean
    while (rest.length > maxLen) {
        val window = rest.substring(0, maxLen)
        var cut = -1
        for (m in listOf(". ", "! ", "? ", "; ", ", ")) {
            val i = window.lastIndexOf(m)
            if (i > maxLen / 3) {
                cut = i + 1
                break
            }
        }
        if (cut < 0) {
            val sp = window.lastIndexOf(' ')
            cut = if (sp > 0) sp else maxLen
        }
        out.add(rest.substring(0, cut).trim())
        rest = rest.substring(cut).trim()
    }
    if (rest.isNotEmpty()) out.add(rest)
    return out
}

fun sha256Hex(text: String): String {
    val bytes = MessageDigest.getInstance("SHA-256").digest(text.toByteArray(Charsets.UTF_8))
    val sb = StringBuilder()
    for (b in bytes) sb.append(String.format("%02x", b))
    return sb.toString()
}
