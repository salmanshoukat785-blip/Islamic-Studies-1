package com.islamicstudies.academy.ui.home

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.islamicstudies.academy.data.db.ChapterSummary
import com.islamicstudies.academy.ui.LocalStrings
import com.islamicstudies.academy.ui.components.BookIcon
import com.islamicstudies.academy.ui.components.TrophyIcon
import com.islamicstudies.academy.ui.theme.DeepGreen
import com.islamicstudies.academy.ui.theme.DeepGreenDark
import com.islamicstudies.academy.ui.theme.Gold
import com.islamicstudies.academy.ui.theme.HeaderTeal
import com.islamicstudies.academy.ui.theme.UrduText
import kotlin.math.cos
import kotlin.math.sin

/** Green header with a moon, stars and a mosque skyline, all drawn with shapes. */
@Composable
fun HeaderArt(modifier: Modifier = Modifier) {
    Canvas(
        modifier = modifier.background(
            Brush.verticalGradient(listOf(DeepGreenDark, DeepGreen, HeaderTeal)),
            RoundedCornerShape(bottomStart = 36.dp, bottomEnd = 36.dp)
        )
    ) {
        val w = size.width
        val h = size.height

        // soft golden glow behind the mosque
        val glowCenter = Offset(w * 0.78f, h * 0.72f)
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Gold.copy(alpha = 0.35f), Color.Transparent),
                center = glowCenter,
                radius = w * 0.5f
            ),
            radius = w * 0.5f,
            center = glowCenter
        )

        // decorative arc in the top-left corner
        drawArc(
            color = Gold.copy(alpha = 0.55f),
            startAngle = 0f,
            sweepAngle = 90f,
            useCenter = false,
            topLeft = Offset(-w * 0.28f, -w * 0.28f),
            size = Size(w * 0.56f, w * 0.56f),
            style = Stroke(width = 3.dp.toPx())
        )

        // stars
        val starColor = Color(0xFFFFE9A8)
        val stars = listOf(
            Triple(0.55f, 0.16f, 2.5f), Triple(0.80f, 0.12f, 2f), Triple(0.90f, 0.30f, 2.5f),
            Triple(0.50f, 0.36f, 2f), Triple(0.72f, 0.40f, 1.5f), Triple(0.95f, 0.10f, 1.5f)
        )
        for (st in stars) {
            val c = Offset(w * st.first, h * st.second)
            val r = st.third.dp.toPx()
            drawCircle(starColor, r, c)
            drawLine(starColor, Offset(c.x - r * 2.5f, c.y), Offset(c.x + r * 2.5f, c.y), strokeWidth = 1.dp.toPx())
            drawLine(starColor, Offset(c.x, c.y - r * 2.5f), Offset(c.x, c.y + r * 2.5f), strokeWidth = 1.dp.toPx())
        }

        // crescent moon
        val moonCenter = Offset(w * 0.68f, h * 0.20f)
        val moonR = w * 0.062f
        val outer = Path().apply { addOval(Rect(center = moonCenter, radius = moonR)) }
        val inner = Path().apply {
            addOval(Rect(center = Offset(moonCenter.x + moonR * 0.55f, moonCenter.y - moonR * 0.15f), radius = moonR * 0.85f))
        }
        drawPath(Path.combine(PathOperation.Difference, outer, inner), Gold)

        // mosque skyline
        val body = Color(0xFF0A3F33)
        val baseY = h * 0.93f
        val hallTop = h * 0.68f
        drawRect(body, Offset(w * 0.60f, hallTop), Size(w * 0.32f, baseY - hallTop))

        val domeCx = w * 0.76f
        val domeR = w * 0.095f
        val dome = Path().apply {
            moveTo(domeCx - domeR, hallTop)
            arcTo(Rect(center = Offset(domeCx, hallTop), radius = domeR), 180f, 180f, false)
            close()
        }
        drawPath(dome, body)
        val spireTop = hallTop - domeR - h * 0.06f
        drawLine(Gold, Offset(domeCx, hallTop - domeR), Offset(domeCx, spireTop), strokeWidth = 2.dp.toPx())
        drawCircle(Gold, 3.dp.toPx(), Offset(domeCx, spireTop))

        for (mx in listOf(w * 0.64f, w * 0.89f)) {
            drawRect(body, Offset(mx - w * 0.014f, h * 0.40f), Size(w * 0.028f, baseY - h * 0.40f))
            val cap = Path().apply {
                moveTo(mx - w * 0.02f, h * 0.40f)
                lineTo(mx, h * 0.30f)
                lineTo(mx + w * 0.02f, h * 0.40f)
                close()
            }
            drawPath(cap, body)
            drawCircle(Gold, 2.dp.toPx(), Offset(mx, h * 0.28f))
        }

        // lit windows
        for (i in 0 until 5) {
            drawRoundRect(
                color = Color(0xFFFFD66B),
                topLeft = Offset(w * (0.64f + i * 0.055f), h * 0.78f),
                size = Size(w * 0.025f, h * 0.10f),
                cornerRadius = CornerRadius(w * 0.012f, w * 0.012f)
            )
        }
    }
}

/** Octagon badge with the chapter number. */
@Composable
fun OctagonBadge(number: Int, badgeSize: Dp) {
    Box(modifier = Modifier.size(badgeSize), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val cx = size.width / 2f
            val cy = size.height / 2f
            val r = size.minDimension / 2f - 2.dp.toPx()
            val path = Path()
            for (k in 0 until 8) {
                val angle = Math.toRadians(22.5 + 45.0 * k)
                val x = cx + r * cos(angle).toFloat()
                val y = cy + r * sin(angle).toFloat()
                if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()
            drawPath(path, DeepGreen)
            drawPath(path, Gold, style = Stroke(width = 2.dp.toPx()))
        }
        Text(
            text = number.toString(),
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 22.sp
        )
    }
}

@Composable
private fun StatItem(label: String, value: String, modifier: Modifier, icon: @Composable () -> Unit) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier.size(46.dp).background(DeepGreen, CircleShape),
            contentAlignment = Alignment.Center
        ) { icon() }
        Spacer(modifier = Modifier.height(6.dp))
        Text(text = value, fontSize = 28.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
        Text(
            text = label,
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun GoldDivider() {
    Box(modifier = Modifier.width(1.dp).height(72.dp).background(Gold.copy(alpha = 0.55f)))
}

/** The card with the overall progress only (no chapter or topic counts). */
@Composable
fun StatsCard(fraction: Float, modifier: Modifier = Modifier) {
    val s = LocalStrings.current
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(30.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier.size(46.dp).background(DeepGreen, CircleShape),
                contentAlignment = Alignment.Center
            ) { TrophyIcon(modifier = Modifier.size(26.dp), color = Gold) }
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(text = s.progressTitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface, textAlign = TextAlign.Center)
                Text(
                    text = (fraction * 100).toInt().toString() + "%",
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(4.dp))
                LinearProgressIndicator(
                    progress = { fraction },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp).height(8.dp).clip(RoundedCornerShape(50)),
                    color = DeepGreen,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )
            }
        }
    }
}

/** One chapter row: number badge, English title, Urdu title and an arrow (no counts). */
@Composable
fun ChapterRowCard(chapter: ChapterSummary, onClick: () -> Unit) {
    // The card keeps the same left-to-right look in both app languages.
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Card(
            modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
            shape = RoundedCornerShape(26.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OctagonBadge(number = chapter.number, badgeSize = 54.dp)
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1.25f)) {
                    Text(
                        text = if (chapter.titleEn.isNotBlank()) chapter.titleEn else chapter.titleUr,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 2
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                GoldDividerSmall()
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = chapter.titleUr,
                    style = UrduText.subheading,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Box(
                    modifier = Modifier.size(40.dp).background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.KeyboardArrowRight,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    }
}

@Composable
private fun GoldDividerSmall() {
    Box(modifier = Modifier.width(1.dp).height(48.dp).background(Gold.copy(alpha = 0.5f)))
}

/** Dark green banner with an open book and the quote. */
@Composable
fun QuoteBanner(text: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(96.dp)
            .background(Brush.horizontalGradient(listOf(DeepGreenDark, DeepGreen)), RoundedCornerShape(26.dp))
            .padding(horizontal = 20.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            BookIcon(modifier = Modifier.size(54.dp), color = Gold)
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                text = text,
                color = Color(0xFFFFE9A8),
                fontSize = 20.sp,
                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                fontFamily = androidx.compose.ui.text.font.FontFamily.Serif,
                textAlign = TextAlign.Center,
                modifier = Modifier.weight(1f)
            )
        }
    }
}
