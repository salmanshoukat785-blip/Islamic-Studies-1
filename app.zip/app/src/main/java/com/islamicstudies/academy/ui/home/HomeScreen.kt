package com.islamicstudies.academy.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.islamicstudies.academy.data.db.ChapterSummary
import com.islamicstudies.academy.data.db.HeadingEntity
import com.islamicstudies.academy.ui.LocalAppLanguage
import com.islamicstudies.academy.ui.LocalStrings
import com.islamicstudies.academy.ui.components.AcademyBottomBar
import com.islamicstudies.academy.ui.isEnglishPrimary
import com.islamicstudies.academy.ui.pickTitle
import com.islamicstudies.academy.ui.screenTitleStyle
import com.islamicstudies.academy.ui.theme.UrduText

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onOpenChapters: () -> Unit,
    onOpenChapter: (String) -> Unit,
    onOpenBookmarks: () -> Unit,
    onOpenNotes: () -> Unit,
    onOpenLesson: (String) -> Unit,
    onOpenQuiz: () -> Unit,
    onOpenSearch: () -> Unit,
    onOpenSettings: () -> Unit,
    onTab: (String) -> Unit,
    viewModel: HomeViewModel = viewModel()
) {
    val s = LocalStrings.current
    val ui by viewModel.ui.collectAsStateWithLifecycle()
    var menuOpen by remember { mutableStateOf(false) }
    var tab by rememberSaveable { mutableStateOf(0) }
    val tabs = listOf(s.tabChapters, s.tabSaved, s.tabOutline, s.tabStudy, s.tabGuide)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = s.headerTitle, style = screenTitleStyle()) },
                actions = {
                    Box {
                        IconButton(onClick = { menuOpen = true }) {
                            Icon(imageVector = Icons.Filled.Menu, contentDescription = null)
                        }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(
                                text = { Text(s.tileQuiz) },
                                onClick = { menuOpen = false; onOpenQuiz() }
                            )
                            DropdownMenuItem(
                                text = { Text(s.tileSearch) },
                                onClick = { menuOpen = false; onOpenSearch() }
                            )
                            DropdownMenuItem(
                                text = { Text(s.tileBookmarks) },
                                onClick = { menuOpen = false; onOpenBookmarks() }
                            )
                            DropdownMenuItem(
                                text = { Text(s.tileNotes) },
                                onClick = { menuOpen = false; onOpenNotes() }
                            )
                            DropdownMenuItem(
                                text = { Text(s.langToggleLabel) },
                                onClick = { menuOpen = false; viewModel.toggleLanguage() }
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    actionIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        },
        bottomBar = { AcademyBottomBar(current = "home", onTab = onTab) }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            ScrollableTabRow(selectedTabIndex = tab, edgePadding = 0.dp) {
                tabs.forEachIndexed { index, label ->
                    Tab(
                        selected = tab == index,
                        onClick = { tab = index },
                        text = { Text(text = label, maxLines = 1) }
                    )
                }
            }
            when (tab) {
                0 -> ChaptersTab(ui = ui, onOpenChapter = onOpenChapter, onOpenSearch = onOpenSearch)
                1 -> SavedTab(onOpenBookmarks = onOpenBookmarks, onOpenNotes = onOpenNotes)
                2 -> OutlineTab(ui = ui, onOpenLesson = onOpenLesson)
                3 -> StudyTab(ui = ui, onOpenLesson = onOpenLesson, onOpenQuiz = onOpenQuiz)
                else -> GuideTab()
            }
        }
    }
}

@Composable
private fun ChaptersTab(ui: HomeUi, onOpenChapter: (String) -> Unit, onOpenSearch: () -> Unit) {
    val s = LocalStrings.current
    var query by rememberSaveable { mutableStateOf("") }
    val total = ui.chapters.size
    val fraction = if (total > 0) ui.studiedChapters.toFloat() / total.toFloat() else 0f
    val q = query.trim()
    val visible = remember(ui.chapters, q) {
        if (q.isEmpty()) {
            ui.chapters
        } else {
            ui.chapters.filter { c -> c.titleEn.contains(q, ignoreCase = true) || c.titleUr.contains(q) }
        }
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item(key = "studied-and-search") {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = s.studiedOf(ui.studiedChapters, total),
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { fraction },
                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(50)),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant
                )
                Spacer(modifier = Modifier.height(14.dp))
                OutlinedTextField(
                    value = query,
                    onValueChange = { text -> query = text },
                    placeholder = { Text(text = s.searchHint) },
                    singleLine = true,
                    trailingIcon = {
                        IconButton(onClick = onOpenSearch) {
                            Icon(imageVector = Icons.Filled.Search, contentDescription = s.tileSearch)
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
        if (visible.isEmpty()) {
            item(key = "no-match") {
                Text(text = s.noMatch, style = MaterialTheme.typography.bodyLarge)
            }
        }
        var lastGroup = ""
        for (chapter in visible) {
            val group = if (chapter.number > CORE_CHAPTER_COUNT) {
                "PMS Paper 6 - Additional Topics"
            } else {
                "Core Islamic Studies Course"
            }
            if (group != lastGroup) {
                lastGroup = group
                item(key = "group-" + group) { CategoryHeader(text = group) }
            }
            item(key = chapter.id) {
                ChapterCard(chapter = chapter, onClick = { onOpenChapter(chapter.id) })
            }
        }
    }
}

/** Chapters 1 to 18 are the core course; later chapters come from the PMS Paper 6 syllabus. */
private const val CORE_CHAPTER_COUNT = 18

@Composable
private fun CategoryHeader(text: String) {
    Text(
        text = text.uppercase(),
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onPrimary,
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp)
            .background(MaterialTheme.colorScheme.primary)
            .padding(horizontal = 14.dp, vertical = 12.dp)
    )
}

@Composable
private fun ChapterCard(chapter: ChapterSummary, onClick: () -> Unit) {
    val uiLang = LocalAppLanguage.current
    val englishFirst = isEnglishPrimary(chapter.titleEn, uiLang)
    val title = pickTitle(chapter.titleUr, chapter.titleEn, uiLang)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = chapter.number.toString() + ".",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.width(12.dp))
        Text(
            text = title,
            style = if (englishFirst) MaterialTheme.typography.titleMedium else UrduText.subheading,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun ActionCard(text: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 18.dp)
        )
    }
}

@Composable
private fun SavedTab(onOpenBookmarks: () -> Unit, onOpenNotes: () -> Unit) {
    val s = LocalStrings.current
    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ActionCard(text = s.tileBookmarks, onClick = onOpenBookmarks)
        ActionCard(text = s.tileNotes, onClick = onOpenNotes)
    }
}

@Composable
private fun OutlineTab(ui: HomeUi, onOpenLesson: (String) -> Unit) {
    val uiLang = LocalAppLanguage.current
    // For each chapter keep only its top-level sections.
    val topSections = remember(ui.sections) {
        ui.sections.groupBy { h -> h.chapterId }.mapValues { entry ->
            val minDepth = entry.value.minOf { h -> h.depth }
            entry.value.filter { h -> h.depth == minDepth }
        }
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        for (chapter in ui.chapters) {
            item(key = "outline-" + chapter.id) {
                Text(
                    text = chapter.number.toString() + ". " + pickTitle(chapter.titleUr, chapter.titleEn, uiLang),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp)
                        .background(MaterialTheme.colorScheme.primary)
                        .padding(horizontal = 14.dp, vertical = 12.dp)
                )
            }
            val sections: List<HeadingEntity> = topSections[chapter.id] ?: emptyList()
            items(sections, key = { h -> "section-" + h.id }) { h ->
                val englishFirst = isEnglishPrimary(h.titleEn, uiLang)
                Text(
                    text = pickTitle(h.titleUr, h.titleEn, uiLang),
                    style = if (englishFirst) MaterialTheme.typography.bodyLarge else UrduText.body,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .clickable { onOpenLesson(h.id) }
                        .padding(horizontal = 14.dp, vertical = 12.dp)
                )
            }
        }
    }
}

@Composable
private fun StudyTab(ui: HomeUi, onOpenLesson: (String) -> Unit, onOpenQuiz: () -> Unit) {
    val s = LocalStrings.current
    val uiLang = LocalAppLanguage.current
    val fraction = if (ui.total > 0) ui.completed.toFloat() / ui.total.toFloat() else 0f
    val last = ui.lastOpened
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        StatsCard(fraction = fraction)
        if (last != null) {
            val lastEnglish = isEnglishPrimary(last.titleEn, uiLang)
            Card(
                modifier = Modifier.fillMaxWidth().clickable { onOpenLesson(last.headingId) },
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.PlayArrow,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(34.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = s.continueLearning,
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text(
                            text = pickTitle(last.titleUr, last.titleEn, uiLang),
                            style = if (lastEnglish) MaterialTheme.typography.titleMedium else UrduText.subheading,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }
        ActionCard(text = s.tileQuiz, onClick = onOpenQuiz)
    }
}

@Composable
private fun GuideTab() {
    val s = LocalStrings.current
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = s.guideTitle,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = s.guideBody,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
