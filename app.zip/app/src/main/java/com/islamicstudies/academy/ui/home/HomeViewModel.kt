package com.islamicstudies.academy.ui.home

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.islamicstudies.academy.AcademyApp
import com.islamicstudies.academy.data.db.ChapterSummary
import com.islamicstudies.academy.data.db.HeadingEntity
import com.islamicstudies.academy.data.db.SavedItem
import com.islamicstudies.academy.data.settings.AppSettings
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class HomeUi(
    val settings: AppSettings = AppSettings(),
    val completed: Int = 0,
    val total: Int = 0,
    val lastOpened: SavedItem? = null,
    val chapters: List<ChapterSummary> = emptyList(),
    /** Number of chapters whose topics are all marked as studied. */
    val studiedChapters: Int = 0,
    /** All section headings of all chapters (for the course outline tab). */
    val sections: List<HeadingEntity> = emptyList()
)

private data class ChapterData(
    val chapters: List<ChapterSummary>,
    val studied: Int,
    val sections: List<HeadingEntity>
)

class HomeViewModel(application: Application) : AndroidViewModel(application) {
    private val app = application as AcademyApp
    private val repo = app.settingsRepository
    private val userDao = app.database.userDao()
    private val contentDao = app.database.contentDao()

    private val studiedChaptersFlow = combine(
        contentDao.observeTopicCounts(),
        userDao.observeCompletedTopicCounts()
    ) { totals, done ->
        val doneMap = done.associate { c -> c.chapterId to c.cnt }
        totals.count { t -> t.cnt > 0 && (doneMap[t.chapterId] ?: 0) >= t.cnt }
    }

    private val chapterData = combine(
        contentDao.observeChapterSummaries(),
        studiedChaptersFlow,
        contentDao.observeSectionHeadings()
    ) { chapters, studied, sections ->
        ChapterData(chapters = chapters, studied = studied, sections = sections)
    }

    val ui: StateFlow<HomeUi> = combine(
        repo.settings,
        userDao.observeCompletedCount(),
        userDao.observeTopicCount(),
        userDao.observeLastOpened(),
        chapterData
    ) { settings, completed, total, last, data ->
        HomeUi(
            settings = settings,
            completed = completed,
            total = total,
            lastOpened = last,
            chapters = data.chapters,
            studiedChapters = data.studied,
            sections = data.sections
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), HomeUi())

    fun toggleLanguage() {
        viewModelScope.launch {
            val next = if (ui.value.settings.language == "en") "ur" else "en"
            repo.setLanguage(next)
        }
    }
}
