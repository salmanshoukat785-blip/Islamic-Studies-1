package com.islamicstudies.academy.ui.theme

import androidx.compose.ui.graphics.Color

val DeepGreen = Color(0xFF07503F)
val DeepGreenDark = Color(0xFF042F27)
val Navy = DeepGreen   // name kept for older code; the colour is now deep green
val Emerald = Color(0xFF0F766E)
val Gold = Color(0xFFC9A227)
val WarmWhite = Color(0xFFF7F2E3)

val NavyContainer = Color(0xFFD3EADF)
val EmeraldContainer = Color(0xFFCDEDE8)
val SandVariant = Color(0xFFEDE8DC)

val DarkBackground = Color(0xFF0C1A16)
val DarkSurface = Color(0xFF14251F)
val DarkPrimary = Color(0xFF8FD3B6)
val DarkSecondary = Color(0xFF5CD1C3)
val DarkTertiary = Color(0xFFE0C15A)
val DarkOnSurface = Color(0xFFE6E1D8)

val HeaderTeal = Color(0xFF0E6B52)
