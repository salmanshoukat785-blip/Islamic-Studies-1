package com.islamicstudies.academy.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.sp
import com.islamicstudies.academy.R

/** Jameel Noori Nastaleeq: used for all Urdu text. */
val UrduFont = FontFamily(Font(R.font.jameel_noori_nastaleeq, FontWeight.Normal))

val AcademyTypography = Typography()

private fun TextStyle.urdu(): TextStyle = copy(
    fontFamily = UrduFont,
    lineHeight = if (lineHeight.isSp) (lineHeight.value * 1.4f).sp else lineHeight
)

/** Typography used when the app language is Urdu: every style uses the Nastaliq font with roomier lines. */
val UrduTypography: Typography = AcademyTypography.let { t ->
    t.copy(
        displayLarge = t.displayLarge.urdu(),
        displayMedium = t.displayMedium.urdu(),
        displaySmall = t.displaySmall.urdu(),
        headlineLarge = t.headlineLarge.urdu(),
        headlineMedium = t.headlineMedium.urdu(),
        headlineSmall = t.headlineSmall.urdu(),
        titleLarge = t.titleLarge.urdu(),
        titleMedium = t.titleMedium.urdu(),
        titleSmall = t.titleSmall.urdu(),
        bodyLarge = t.bodyLarge.urdu(),
        bodyMedium = t.bodyMedium.urdu(),
        bodySmall = t.bodySmall.urdu(),
        labelLarge = t.labelLarge.urdu(),
        labelMedium = t.labelMedium.urdu(),
        labelSmall = t.labelSmall.urdu()
    )
}

/** Urdu text styles: Nastaliq needs generous line height; direction is taken from the content. */
object UrduText {
    val title = TextStyle(
        fontFamily = UrduFont,
        fontSize = 20.sp,
        lineHeight = 42.sp,
        fontWeight = FontWeight.Bold,
        textDirection = TextDirection.Content
    )
    val subheading = TextStyle(
        fontFamily = UrduFont,
        fontSize = 18.sp,
        lineHeight = 38.sp,
        fontWeight = FontWeight.SemiBold,
        textDirection = TextDirection.Content
    )
    val body = TextStyle(
        fontFamily = UrduFont,
        fontSize = 18.sp,
        lineHeight = 44.sp,
        textDirection = TextDirection.Content
    )
}
