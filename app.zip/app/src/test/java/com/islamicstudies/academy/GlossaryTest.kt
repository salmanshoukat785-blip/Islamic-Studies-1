package com.islamicstudies.academy

import com.islamicstudies.academy.data.glossary.GlossaryStore
import com.islamicstudies.academy.data.glossary.findGlossaryHits
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

/** Checks assets/glossary.json and the word-finding rules. */
class GlossaryTest {

    private val terms = GlossaryStore.parse(File("src/main/assets/glossary.json").readText(Charsets.UTF_8))

    @Test
    fun glossaryFileIsValid() {
        assertTrue("glossary is empty", terms.isNotEmpty())
        assertEquals("duplicate ids", terms.size, terms.map { t -> t.id }.toSet().size)
        for (t in terms) {
            assertTrue("blank term in ${t.id}", t.termEn.isNotBlank() && t.termUr.isNotBlank())
            assertTrue("blank meaning in ${t.id}", t.meaningEn.isNotBlank() && t.meaningUr.isNotBlank())
            assertTrue("no English spelling for ${t.id}", t.matchEn.isNotEmpty())
        }
    }

    @Test
    fun findsWholeWordsOnly() {
        val hits = findGlossaryHits("Pay zakah every year. Zakah is a pillar.", "en", terms)
        assertEquals(1, hits.count { h -> h.term.id == "zakah" })
        val none = findGlossaryHits("The zakahxyz word is not a match.", "en", terms)
        assertTrue(none.none { h -> h.term.id == "zakah" })
    }

    @Test
    fun findsUrduWords() {
        val hits = findGlossaryHits("حج اور زکوٰۃ اسلام کے ارکان ہیں۔", "ur", terms)
        val ids = hits.map { h -> h.term.id }
        assertTrue(ids.contains("hajj"))
        assertTrue(ids.contains("zakah"))
    }
}
